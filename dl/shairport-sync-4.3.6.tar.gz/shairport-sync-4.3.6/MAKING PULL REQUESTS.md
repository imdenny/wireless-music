Making Pull Requests
====

If you would like to make pull requests (PRs) to Shairport Sync, please base them on the `development` branch.

Changes and additions in the `development` branch make their way eventually to the `master` branch.
